import sqlite3
import pandas as pd

conn = sqlite3.connect("inventory.db")
cursor = conn.cursor()

df = pd.read_csv("supermarket_sales.csv")

for index, row in df.iterrows():
    cursor.execute(
        "INSERT INTO sales (product_id, quantity, sale_time) VALUES (?, ?, ?)",
        (1, row['Quantity'], row['Date'])
    )

conn.commit()
conn.close()

print("Dataset inserted successfully!")
