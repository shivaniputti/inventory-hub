import sqlite3
from datetime import datetime

conn = sqlite3.connect("inventory.db")
cursor = conn.cursor()

def add_sale():
    product_id = int(input("Enter Product ID: "))
    quantity = int(input("Enter Quantity: "))

    cursor.execute("SELECT stock FROM products WHERE id=?", (product_id,))
    result = cursor.fetchone()

    if result is None:
        print("Product not found")
        return

    stock = result[0]

    if quantity > stock:
        print("Not enough stock")
        return

    new_stock = stock - quantity

    cursor.execute("UPDATE products SET stock=? WHERE id=?", (new_stock, product_id))

    time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute(
        "INSERT INTO sales (product_id, quantity, sale_time) VALUES (?, ?, ?)",
        (product_id, quantity, time)
    )

    conn.commit()
    print("Sale added successfully")


def view_sales():
    cursor.execute("""
    SELECT sales.sale_id, products.name, sales.quantity, sales.sale_time
    FROM sales
    JOIN products ON sales.product_id = products.id
    """)

    data = cursor.fetchall()

    print("\nSales History:")
    for row in data:
        print(row)


while True:
    print("\n1. Add Sale")
    print("2. View Sales")
    print("3. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        add_sale()
    elif choice == "2":
        view_sales()
    elif choice == "3":
        break
    else:
        print("Invalid choice")

conn.close()
